#include "node.h"

using namespace std;

node::node(){
  next = nullptr;
}
