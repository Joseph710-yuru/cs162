#ifndef NODE_H
#define NODE_H

class node {
  public:
    int val;
    node *next;
    node();
};

#endif
