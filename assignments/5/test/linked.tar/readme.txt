Name: Garrett Martin
Description: It's a program that takes asks you for integers, puts them
             in a singly linked list. It then asks how you'd like them sorted,
             prints them in whichever order in addition to the number of primes
             in your list and the specific prime number.

Extra credit: none
